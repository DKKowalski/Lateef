# Changelog

## 0.2.0-beta.1 — review build

- Lateef working brand and extension icon set; compatibility with previous CLI and state directory retained.
- Browser upload tool for 1–4 authorized regular files, 2 MiB total, with exact origin guard and hidden file-input references.
- DOM rows/cells, semantic depth, visible leaf text, link destinations and explicit truncation diagnostics.
- Setup/config/doctor commands; version/capability reporting and outdated-broker upload refusal.
- Sanitized release export, CI, product-page and store-submission drafts.

Not yet published. Live Gmail Sent/attachments, broader platform support, final publisher/contact, store approval and independent review remain release gates.
