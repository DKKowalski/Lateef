# Chrome Web Store submission draft

Name: Lateef — browser tools for AI agents
Version: 0.2.0 (version name 0.2.0 beta 1)
Short description: Connect AI tools to selected Chrome tabs through a local MCP bridge.

## Overview

Your agent can browse. You can keep working.

Lateef connects an MCP-compatible AI client to the Chrome profile you already use. Pair one existing window, let agents open inactive tabs, and share existing tabs explicitly when needed.

Read page content, find links and controls, fill supported fields, click elements and attach authorized files. Each session sees its own tabs and those you share; guessing a tab ID grants no access. Stop the companion, disconnect the extension or revoke pairing to end access.

A separate local Node.js 22+ companion and MCP-client configuration are required. Installing this extension alone is not sufficient. The beta supports files totaling up to 2 MiB per call. Password entry, iframes, downloads and hardware-input-dependent pages are unsupported. macOS has been tested; other platforms need validation. Gmail attachment support is not yet verified.

Page content and selected file bytes pass to your AI client and may be sent to its AI provider. Lateef has no hosted backend, ads or analytics. Read the privacy notice and your AI client's policies.

## Single purpose

Provide structured, session-scoped browser tools to a user-chosen local MCP client through a paired Chrome window.

## Permission explanations

- tabs: create/list/close owned background tabs and verify their bound window.
- scripting: run packaged DOM read/action functions in authorized HTTP(S) tabs.
- storage: keep pairing credentials and local session ownership.
- alarms: reconnect the local companion after worker suspension/disconnection.
- HTTP(S) host access: read/act on sites the user asks the agent to use, constrained by session ownership. The current broad host scope must be reviewed and justified; do not call this a per-site permission implementation.
- loopback HTTP/WebSocket: connect only to the installed local companion on 127.0.0.1. Explain authentication and local transport to reviewers; it is not TLS.

## Reviewer steps

Use synthetic files/accounts. Download the exact tagged companion source matching this extension. Run npm ci, then node bin/quiet-chrome.mjs pair. Enter the code/port in this extension in an existing Chrome window. Configure an MCP client with node bin/quiet-chrome.mjs config. Reconnect, call browser_status, create an example.com tab, snapshot it, then close it. The companion has no subscription or provider-account dependency; the chosen MCP client may have its own requirements. Upload testing must use a synthetic local/test form, not private mail.

## Publication fields still requiring real values

Publisher account/identity and support contact; final source repository URL; hosted homepage/privacy/support URLs; final name availability; final package distribution link. Do not submit this draft with missing fields or placeholder addresses. Enable private vulnerability reporting before publishing the repository.

Official checklist references:
https://developer.chrome.com/docs/webstore/register
https://developer.chrome.com/docs/webstore/publish
https://developer.chrome.com/docs/webstore/images
https://developer.chrome.com/docs/webstore/program-policies/user-data-faq
