# Review before publication

This directory is a launch draft. No public repository, npm publication, domain purchase, Chrome Web Store submission or announcement is performed by preparation.

Review the generated source ZIP, extension ZIP, npm tarball, checksums, local product page and brand assets. The source export is an allowlist: personal real-profile/evaluation docs, credentials, state, screenshots of real accounts, artifacts and school documents are excluded.

Release gates still requiring real-world validation/ownership:
- Live Gmail Sent and Gmail attachment compatibility with the loaded beta.
- A clean install by a tester in an actual MCP client; global registration is not silently modified.
- Windows/Linux testing and independent security review before claiming broad support or audited security.
- Final publisher account/contact, repository/npm ownership, name/domain availability, public privacy URL and store approval.

The generated product page honestly states source-beta status. All download links should resolve in the review bundle. A store listing must explain the separate local companion. Review the allowlisted source rather than publishing the working research directory wholesale.
