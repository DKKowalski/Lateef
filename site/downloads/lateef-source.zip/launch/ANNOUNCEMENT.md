# Launch copy — draft, not posted

Show HN title: Lateef – open-source MCP tools for background tabs in your existing Chrome

I built Lateef because I wanted my AI tools to use the Chrome profile I already use, without turning every browser task into a foreground interruption.

It is a small MV3 extension plus a local MCP companion. You pair an existing window; each AI session gets its own inactive tabs. Existing tabs need explicit sharing. The tools read pages, fill fields, follow links and attach authorized files. There are no runtime screenshots or desktop-control tools.

This is a developer beta. Setup needs Node.js 22+ and an MCP client. Uploads are limited to 2 MiB; Gmail attachments and broad cross-platform compatibility are still being validated. The bridge is local, but selected content passes to the connected AI client and may reach its model provider.

The source is MIT licensed. I'd especially like feedback on onboarding, complex DOMs and reconnect behaviour. Final public source/install links must be added before posting.

## Short demo storyboard

Use synthetic data only. Show a user working in a foreground editor. In a new owned Chrome tab, the agent reads a test form, fills a label-referenced field and attaches a synthetic PDF. Show the local upload fixture confirming the file. End on the extension's session-sharing and disconnect controls. Mark illustrative sequences and speed-ups. Avoid real inboxes, addresses or application documents.

## Launch order

Clean source review → small developer beta → fix onboarding issues → final public URLs/contact and name checks → tagged source/npm package → store review with deferred publication → coordinated product page, store listing and post.

Do not advertise the old one-task token result as general savings. If mentioning it, publish the task, cache accounting, both model versions, date and raw redacted counts alongside it.
