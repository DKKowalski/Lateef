import { chromium } from 'playwright-core';
import { readFile, stat, mkdir } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
const root=resolve('site/dist');const errors=[];
const browser=await chromium.launch({headless:true,executablePath:process.env.QUIET_CHROME_TEST_CHROMIUM,channel:process.env.QUIET_CHROME_TEST_CHROMIUM?undefined:'chromium'});
try{
 await mkdir('artifacts/site',{recursive:true});
 for(const width of [1280,390]){
 const page=await browser.newPage({viewport:{width,height:900}});page.on('pageerror',e=>errors.push(e.message));
 for(const name of ['index.html','install.html','privacy.html','security.html']){
  await page.goto(pathToFileURL(join(root,name)).href);
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
  if(overflow)throw Error(`Horizontal overflow: ${name} at ${width}`);
  for(const href of await page.locator('a[href]').evaluateAll(as=>as.map(a=>a.getAttribute('href')))){
   if(href.startsWith('#')){if(!await page.locator(href).count())throw Error('Missing anchor '+href);}
   else if(!/^https?:/.test(href))await stat(resolve(root,href.split('#')[0]));
  }
  if(name==='index.html'){
    await page.waitForFunction(()=>document.querySelector('.bento')?.style.getPropertyValue('--demo-time'));
    const position=()=>page.locator('.bento').evaluate(el=>el.style.getPropertyValue('--demo-time'));
    const before=await position();await page.waitForTimeout(150);if(before===await position())throw Error('Motion did not advance');
    await page.locator('[data-motion-toggle]').click();const paused=await position();await page.waitForTimeout(150);if(paused!==await position())throw Error('Pause did not freeze the demo');
    await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(100);const reduced=await position();await page.waitForTimeout(150);if(reduced!==await position())throw Error('Reduced motion is not stable');
    await page.emulateMedia({reducedMotion:'no-preference'});
    await page.locator('[data-motion-replay]').click();
    await page.waitForTimeout(1600);
    const route=await page.locator('.route-ink').evaluate(el=>parseFloat(getComputedStyle(el).strokeDashoffset));
    if(!(route>0&&route<1))throw Error('SVG route does not draw progressively');
    const arrow=page.locator('.hero-aside .interactive-arrow .arrow-shaft');
    const original=await arrow.getAttribute('d');await page.locator('.hero-aside .button').focus();await page.waitForTimeout(65);
    if(original===await arrow.getAttribute('d'))throw Error('Keyboard focus did not animate the SVG arrow');
    await page.evaluate(()=>document.activeElement.blur());await page.waitForTimeout(900);
    await page.evaluate(()=>window.LateefMotion.mount(document.querySelector('.demo-section')).seek(10));
    const scene=page.locator('.demo-section');
    await scene.locator('[data-access-toggle]').click();await page.waitForTimeout(230);
    if((await scene.locator('[data-access-toggle]').getAttribute('aria-pressed'))!=='false')throw Error('Revoke action not reflected in accessibility state');
    if(await scene.locator('.route-ink').evaluate(el=>parseFloat(getComputedStyle(el).strokeDashoffset))<.99)throw Error('Revoked route still visible');
    await scene.locator('[data-access-toggle]').click();await page.waitForTimeout(450);
    if(await scene.locator('.route-ink').evaluate(el=>parseFloat(getComputedStyle(el).strokeDashoffset))>.01)throw Error('Shared route not restored');
    await page.evaluate(()=>{const source=document.querySelector('.demo-section');const copy=source.cloneNode(true);source.after(copy);const a=window.LateefMotion.mount(source),b=window.LateefMotion.mount(copy);a.seek(1);b.seek(10);const ids=[...document.querySelectorAll('svg [id]')].map(el=>el.id);if(new Set(ids).size!==ids.length)throw Error('Duplicate SVG IDs');const [first,second]=document.querySelectorAll('.route-ink');if(getComputedStyle(first).strokeDashoffset===getComputedStyle(second).strokeDashoffset)throw Error('Scenes do not animate independently');copy.querySelector('[data-access-toggle]').click();b.destroy();const remount=window.LateefMotion.mount(copy);remount.seek(10);if(copy.querySelector('[data-access-toggle]').getAttribute('aria-pressed')!=='false')throw Error('Remount lost access choice');remount.destroy();copy.remove();a.seek(8);});

    const settled=await arrow.getAttribute('d');await page.waitForTimeout(100);if(settled!==await arrow.getAttribute('d'))throw Error('SVG spring did not settle');

  }
  if(name==='index.html')await page.screenshot({path:resolve(`artifacts/site/home-${width}.png`),fullPage:true});
 }
 await page.close();
 }
 if(errors.length)throw Error(errors.join('; '));
 console.log('PASS: desktop/mobile layouts, internal links/downloads, page scripts, motion/pause/reduced-motion; all browser pages closed.');
}finally{await browser.close();}
