import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readUploads, MAX_UPLOAD_BYTES } from '../src/uploads.mjs';
test('uploads read exact regular-file bytes, reject oversize/count/relative paths, directories and symlinks', async t => {
 const dir=await mkdtemp(join(tmpdir(),'lateef-upload-'));t.after(()=>rm(dir,{recursive:true,force:true}));
 const path=join(dir,'example.pdf');await writeFile(path,Buffer.from('%PDF-1.4\nfixture\n'));
 const [file]=await readUploads([path]);assert.equal(file.name,'example.pdf');assert.equal(file.type,'application/pdf');assert.equal(Buffer.from(file.data,'base64').toString(),'%PDF-1.4\nfixture\n');
 await assert.rejects(readUploads(['relative.pdf']),/absolute/);await assert.rejects(readUploads([]));await assert.rejects(readUploads([dir]),/regular/);
 await writeFile(join(dir,'large'),Buffer.alloc(MAX_UPLOAD_BYTES+1));await assert.rejects(readUploads([join(dir,'large')]),/2 MiB/);
 if(process.platform!=='win32'){await symlink(path,join(dir,'link'));await assert.rejects(readUploads([join(dir,'link')]),/regular file/);}
});
