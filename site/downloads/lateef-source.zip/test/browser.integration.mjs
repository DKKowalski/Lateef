import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { createServer } from 'node:http';
import { chromium } from 'playwright-core';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { Broker } from '../src/broker.mjs';
import { request } from '../src/client.mjs';

async function until(fn) { const end = Date.now() + 10000; while (Date.now() < end) { if (await fn()) return; await new Promise(resolve => setTimeout(resolve, 50)); } throw new Error('Condition timed out'); }
const parse = result => JSON.parse(result.content[0].text);

test('real unpacked extension: background DOM workflow, MCP stdio, isolation and closed-window refusal', { timeout: 60000 }, async t => {
  await mkdir('artifacts', { recursive: true });
  const directory = await mkdtemp(join(tmpdir(), 'quiet-chrome-browser-'));
  const broker = await Broker.create(join(directory, 'state'), { port: 0 }); await broker.start();
  let context, http, client, second;
  const uploaded = [];
  t.after(async () => { await client?.close(); await second?.close(); await context?.close(); await broker.stop(); if (http) await new Promise(resolve => http.close(resolve)); await rm(directory, { recursive: true, force: true }); });
  const executablePath = process.env.QUIET_CHROME_TEST_CHROMIUM;
  const extensionPath = resolve('extension');
  context = await chromium.launchPersistentContext(join(directory, 'browser'), {
    headless: true, executablePath, channel: executablePath ? undefined : 'chromium',
    args: [`--disable-extensions-except=${extensionPath}`, `--load-extension=${extensionPath}`],
  });
  const errors = [];
  context.on('weberror', error => errors.push(error.error().message));
  http = createServer((req, res) => {
    if (req.url === '/upload') {
      const chunks=[]; req.on('data', c=>chunks.push(c)); req.on('end', ()=>{uploaded.push({bytes:Buffer.concat(chunks),type:req.headers['content-type']});res.end('Attachment received');});return;
    }
    res.writeHead(200, { 'content-type': 'text/html' });
    if (req.url === '/deep') {
      res.end('<!doctype html><title>Deep inbox fixture</title><main>' + '<div>'.repeat(45) + '<div style="display:contents"><div role="grid"><div role="row"><div role="gridcell"><span>Request for a reference</span></div><div role="gridcell"><button>Open reference message</button></div></div></div></div>' + '</div>'.repeat(45) + '</main>');
      return;
    }
    res.end('<!doctype html><title>Quiet Chrome owned fixture</title><h1>Background fixture</h1><label>Test value<input id="value"></label><input type="password" value="do-not-return"><button onclick="document.querySelector(\'output\').textContent=\'Passed: \'+document.querySelector(\'input\').value">Check</button><output>Ready</output><label for="attachment">PDF attachment</label><input type="file" id="attachment" style="display:none" onchange="fetch(\'/upload\',{method:\'POST\',body:this.files[0]}).then(r=&gt;r.text()).then(t=&gt;document.querySelector(\'output\').textContent=t)"><a href="/spa" target="_blank" onclick="event.preventDefault(); history.pushState({}, \'\', this.href); document.querySelector(\'output\').textContent=\'SPA routed\'">SPA route</a><a href="/external" target="_blank">SPA route</a><a href="/next" target="_blank">Open another page</a>');
  });
  await new Promise(resolve => http.listen(0, '127.0.0.1', resolve));
  const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const extensionId = new URL(worker.url()).host;
  const fixture = `http://127.0.0.1:${http.address().port}/`;
  const sentinel = await context.newPage(); await sentinel.goto(fixture + 'sentinel');
  const popup = await context.newPage(); popup.on('pageerror', error => errors.push(error.message));
  await popup.goto(`chrome-extension://${extensionId}/popup.html`);
  await popup.locator('#port').fill(String(broker.port)); await popup.locator('#code').fill(broker.issueCode());
  await popup.getByRole('button', { name: 'Pair this window' }).click();
  try { await until(() => broker.extensions.size === 1); }
  catch {
    const diagnostic = await popup.evaluate(() => ({ handler: String(document.getElementById('pair').onsubmit), resources: performance.getEntriesByType('resource').map(x => ({ name: x.name, size: x.decodedBodySize })), extension: chrome.runtime.id }));
    throw new Error('Extension pairing did not connect: ' + await popup.locator('#error').innerText() + '; ' + await popup.locator('#status').innerText() + '; JS errors: ' + JSON.stringify(errors) + '; ' + JSON.stringify(diagnostic));
  }
  await until(async()=> (await popup.locator('#status').innerText()).includes('Connected'));
  await popup.setViewportSize({width:1280,height:800});
  await popup.screenshot({path:resolve('artifacts/store-popup.png')});
  await popup.close();
  const before = await worker.evaluate(async () => ({ windows: (await chrome.windows.getAll()).map(w => w.id), active: (await chrome.tabs.query({ active: true })).map(tab => tab.id) }));
  const transport = new StdioClientTransport({ command: process.execPath, args: [resolve('bin/quiet-chrome.mjs'), 'mcp'], env: { ...process.env, QUIET_CHROME_STATE_DIR: join(directory, 'state') } });
  client = new Client({ name: 'browser-test-client', version: '1.0' }); await client.connect(transport);
  const tools = await client.listTools(); assert.equal(tools.tools.length, 8); assert.equal(tools.tools.some(tool => /screenshot|claude|playwright/.test(tool.name)), false);
  const call = async (name, args) => { const result = await client.callTool({ name, arguments: args }); if (result.isError) throw new Error(result.content[0].text); return parse(result); };
  assert.equal((await call('browser_status', {})).connected, true);
  const tab = await call('browser_tabs', { action: 'new', url: fixture });
  await until(async () => (await worker.evaluate(id => chrome.tabs.get(id), tab.tabId)).status === 'complete');
  const snapshot = await call('browser_snapshot', { tabId: tab.tabId });
  assert.equal(JSON.stringify(snapshot).includes('do-not-return'), false);
  const input = snapshot.nodes.find(node => node.name === 'Test value'), button = snapshot.nodes.find(node => node.name === 'Check');
  assert.ok(input && button);
  await call('browser_fill', { tabId: tab.tabId, ref: input.ref, value: 'quiet-ok' });
  await call('browser_click', { tabId: tab.tabId, ref: button.ref });
  const verified = await call('browser_snapshot', { tabId: tab.tabId }); assert.match(verified.text, /Passed: quiet-ok/);
  const stale = await client.callTool({ name: 'browser_click', arguments: { tabId: tab.tabId, ref: button.ref } }); assert.equal(stale.isError, true);
  // A target=_blank SPA link must run its handler, route in place, and
  // create no additional tab. Repeat to catch the reported intermittent path.
  for (let i = 0; i < 3; i++) {
    const fresh = await call('browser_snapshot', { tabId: tab.tabId });
    assert.equal(fresh.nodes.filter(node => node.name === 'SPA route').length, 2);
    const spa = fresh.nodes.find(node => node.name === 'SPA route' && node.href === fixture + 'spa');
    const routed = await call('browser_click', { tabId: tab.tabId, ref: spa.ref });
    assert.equal(routed.opened, undefined);
    const routeSnapshot = await call('browser_snapshot', { tabId: tab.tabId });
    assert.match(routeSnapshot.url, /\/spa$/);
    assert.match(routeSnapshot.text, /SPA routed/);
    assert.equal((await call('browser_tabs', { action: 'list' })).tabs.length, 1);
  }
  const links = await call('browser_snapshot', { tabId: tab.tabId });
  const link = links.nodes.find(node => node.name === 'Open another page');
  assert.equal(link.href, fixture + 'next');
  assert.equal(link.target, '_blank');
  assert.match(links.text, /href=.*next/);
  const linked = await call('browser_click', { tabId: tab.tabId, ref: link.ref }); assert.equal(linked.opened.windowId, tab.windowId);
  const after = await worker.evaluate(async () => ({ windows: (await chrome.windows.getAll()).map(w => w.id), active: (await chrome.tabs.query({ active: true })).map(tab => tab.id) }));
  assert.deepEqual(after, before, 'background tool actions must not change active tabs or create windows');
  const uploadSnapshot = await call('browser_snapshot', { tabId: tab.tabId });
  const fileInput = uploadSnapshot.nodes.find(n=>n.role==='file'); assert.ok(fileInput); assert.equal(fileInput.hidden,true);
  const pdfPath=join(directory,'example.pdf');await writeFile(pdfPath,'%PDF-1.4\nlocal fixture\n');
  const rejectedOrigin=await client.callTool({name:'browser_upload',arguments:{tabId:tab.tabId,ref:fileInput.ref,expectedOrigin:'https://wrong.invalid',paths:[pdfPath]}});
  assert.equal(rejectedOrigin.isError,true);assert.match(rejectedOrigin.content[0].text,/ORIGIN_MISMATCH/);assert.equal(uploaded.length,0);
  const attached=await call('browser_upload',{tabId:tab.tabId,ref:fileInput.ref,expectedOrigin:new URL(fixture).origin,paths:[pdfPath]});
  assert.equal(attached.attached[0].name,'example.pdf');
  await until(()=>uploaded.length===1);assert.equal(uploaded[0].bytes.toString(),'%PDF-1.4\nlocal fixture\n');assert.equal(uploaded[0].type,'application/pdf');
  const boundaryPath=join(directory,'boundary.pdf');await writeFile(boundaryPath,Buffer.alloc(2*1024*1024,65));
  const boundary=await call('browser_upload',{tabId:tab.tabId,ref:fileInput.ref,expectedOrigin:new URL(fixture).origin,paths:[boundaryPath]});
  assert.equal(boundary.bytes,2*1024*1024);await until(()=>uploaded.length===2);assert.equal(uploaded[1].bytes.length,2*1024*1024);assert.ok(uploaded[1].bytes.every(b=>b===65));
  const afterUpload=await worker.evaluate(async()=>({windows:(await chrome.windows.getAll()).map(w=>w.id),active:(await chrome.tabs.query({active:true})).map(t=>t.id)}));
  assert.deepEqual(afterUpload,before,'file upload must not activate a tab or create a window');
  const deep = await call('browser_tabs', { action: 'new', url: fixture + 'deep' });
  const deepSnapshot = await call('browser_snapshot', { tabId: deep.tabId });
  assert.match(deepSnapshot.text, /Request for a reference/);
  assert.ok(deepSnapshot.nodes.some(n => n.role === 'row' && n.name.includes('Request for a reference')));
  assert.ok(deepSnapshot.nodes.some(n => n.role === 'button' && n.name === 'Open reference message'));
  assert.equal(deepSnapshot.truncated, false);
  const deepFind = await call('browser_find', { tabId: deep.tabId, text: 'Request for a reference', maxChars: 20000, depth: 30 });
  assert.ok(deepFind.matches.length > 0);
  const shallow = await call('browser_snapshot', { tabId: deep.tabId, depth: 1 });
  assert.equal(shallow.truncated, true);
  assert.ok(shallow.truncationReasons.includes('depth'));
  assert.equal(shallow.limits.depth, 1);
  await call('browser_tabs', { action: 'close', tabId: deep.tabId });
  second = new Client({ name: 'second-client', version: '1.0' }); await second.connect(new StdioClientTransport({ command: process.execPath, args: [resolve('bin/quiet-chrome.mjs'), 'mcp'], env: { ...process.env, QUIET_CHROME_STATE_DIR: join(directory, 'state') } }));
  const isolated = parse(await second.callTool({ name: 'browser_tabs', arguments: { action: 'list' } })); assert.deepEqual(isolated.tabs, []);
  const blocked = await second.callTool({ name: 'browser_snapshot', arguments: { tabId: tab.tabId } }); assert.equal(blocked.isError, true); assert.match(blocked.content[0].text, /TAB_NOT_SHARED/);
  const blockedUpload = await second.callTool({name:'browser_upload',arguments:{tabId:tab.tabId,ref:fileInput.ref,expectedOrigin:new URL(fixture).origin,paths:[pdfPath]}});
  assert.equal(blockedUpload.isError,true);assert.match(blockedUpload.content[0].text,/TAB_NOT_SHARED/);assert.equal(uploaded.length,2);
  const beforeClosedWindow = await worker.evaluate(async () => { const window = await chrome.windows.create({ focused: false }); return window.id; });
  // Close a separately selected empty window. Existing test tabs stay untouched;
  // a closed binding must never trigger a replacement window.
  const settings = await worker.evaluate(() => chrome.storage.local.get('connection'));
  await worker.evaluate(async id => { const { connection } = await chrome.storage.local.get('connection'); connection.windowId = id; await chrome.storage.local.set({ connection }); await chrome.windows.remove(id); }, beforeClosedWindow);
  const refused = await client.callTool({ name: 'browser_tabs', arguments: { action: 'new', url: fixture } }); assert.equal(refused.isError, true); assert.match(refused.content[0].text, /WINDOW_CLOSED/);
  assert.deepEqual((await worker.evaluate(() => chrome.windows.getAll())).map(w => w.id), before.windows);
  await worker.evaluate(connection => chrome.storage.local.set({ connection }), settings.connection);
  // Sharing must be explicitly initiated by our extension UI, and must never
  // give an agent permission to close a user-created tab.
  const sharing = await context.newPage(); await sharing.goto(`chrome-extension://${extensionId}/popup.html`);
  const activeSession = [...broker.sessions.values()].find(session => session.name === 'browser-test-client');
  const sentinelId = await worker.evaluate(async url => (await chrome.tabs.query({})).find(tab => tab.url === url).id, fixture + 'sentinel');
  const shared = await sharing.evaluate(args => chrome.runtime.sendMessage({ type: 'share', ...args }), { sessionId: activeSession.id, tabId: sentinelId });
  assert.equal(shared.ok, true);
  const closeUserTab = await client.callTool({ name: 'browser_tabs', arguments: { action: 'close', tabId: sentinelId } });
  assert.equal(closeUserTab.isError, true); assert.match(closeUserTab.content[0].text, /NOT_OWNED/);
  await sharing.close();
  await call('browser_tabs', { action: 'close', tabId: tab.tabId });
  await client.close(); client = null;
  await until(() => !broker.sessions.has(activeSession.id));
  assert.ok(await worker.evaluate(id => chrome.tabs.get(id), sentinelId), 'user tab survives session cleanup');
  assert.equal(await worker.evaluate(id => chrome.tabs.get(id).then(() => true, () => false), linked.opened.tabId), false, 'agent-created link tab is cleaned up');
  const report = { mcpTools: tools.tools.map(tool => tool.name), backgroundStateBefore: before, backgroundStateAfter: after, formPassed: true, fileUploadExactBytesPassed: true, uploadOriginGuardPassed: true, deepGridRowsCaptured: true, nestedRowButtonsCaptured: true, truncationReported: true, targetBlankStayedInBackground: true, spaTargetBlankRoutedInPlace: true, passwordRedacted: true, staleReferencesRejected: true, sessionIsolationPassed: true, closedWindowRefused: true, sharedTabProtected: true, sessionCleanupPassed: true, productScreenshotsTaken: 0, developmentScreenshotsTaken: 1, errors };
  await writeFile(resolve('artifacts/browser-validation.json'), JSON.stringify(report, null, 2));
  assert.deepEqual(errors, []);
});
