const $ = id => document.getElementById(id);
async function send(msg) { const reply = await chrome.runtime.sendMessage(msg); if (!reply?.ok) throw new Error(reply?.error || 'Extension did not answer'); return reply.result; }
async function refresh() {
  const state = await send({ type: 'status' });
  $('version').textContent = 'Extension ' + (state.version || 'legacy');
  $('status').textContent = state.status + (state.windowId ? ` · Window ${state.windowId}` : '');
  $('pair').hidden = state.paired; $('connected').hidden = !state.paired;
  const selected = $('sessions').value;
  $('sessions').replaceChildren(...state.sessions.map(session => { const option = document.createElement('option'); option.value = session.id; option.textContent = session.name; return option; }));
  if (state.sessions.some(session => session.id === selected)) $('sessions').value = selected;
}
function action(fn) { return async event => { event?.preventDefault(); $('error').textContent = ''; try { await fn(); await refresh(); } catch (error) { $('error').textContent = error.message; } }; }
$('pair').onsubmit = action(async () => {
  const window = await chrome.windows.getCurrent();
  await send({ type: 'pair', port: Number($('port').value), code: $('code').value.trim(), name: $('name').value, windowId: window.id }); $('code').value = '';
});
$('window').onclick = action(async () => { const window = await chrome.windows.getCurrent(); await send({ type: 'window', windowId: window.id }); });
$('share').onclick = action(async () => { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); await send({ type: 'share', tabId: tab.id, sessionId: $('sessions').value }); });
$('disconnect').onclick = action(() => send({ type: 'disconnect' }));
await refresh(); setInterval(() => refresh().catch(() => {}), 2000);
