# Lateef privacy notice — beta draft

Lateef connects a local MCP client to selected Chrome tabs. It has no hosted product backend, advertising, analytics or telemetry. The product site uses local assets and no analytics scripts.

The extension processes URLs, titles, visible page text, field contents (password values are excluded), references and files deliberately selected for upload. The local companion routes tool results to your MCP client. That client may store transcripts and send browser content to a remote AI provider. Websites receive navigation, form data and uploaded files under their own policies. Lateef does not claim to control those services' retention or use.

Pairing credentials and browser names are stored in a private local state directory and Chrome extension storage. Tab ownership is kept in Chrome session storage. Page results and uploaded bytes are handled in memory by the bridge; no product transcript is written by it. Your AI client, OS, browser and website may retain data independently. Network traffic between extension and companion uses authenticated HTTP/WebSocket on 127.0.0.1; it is not encrypted TLS and is not designed to resist a compromised local user account.

Share existing tabs explicitly in the popup. Each session otherwise controls only tabs it creates. Disconnect in the popup, revoke a browser using the CLI, or stop the local broker to end access. To remove local state after stopping all clients, delete the state directory you configured; remove extension storage by uninstalling the extension. This does not remove AI-client or website records.

The extension requests tabs, storage, scripting, alarms and HTTP(S) host access to provide the browser tools. It does not request cookies, debugger, clipboard or desktop capture permissions. Host permissions are broad; agent access is further constrained by pairing, explicit window binding and session ownership. See SECURITY.md for limits.

Chrome Web Store Limited Use: data accessed through Lateef is used for its disclosed browser-tool functionality, not advertising, sale or credit decisions. The final publisher must verify that this notice, store dashboard disclosures and shipped behaviour agree before publication.

This is an unpublished review draft. A publisher identity and support/privacy contact must be attached to the public listing before submission. No fictitious contact is provided here.
