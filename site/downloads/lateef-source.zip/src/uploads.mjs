import { open } from 'node:fs/promises';
import { constants } from 'node:fs';
import { isAbsolute, basename, extname } from 'node:path';
export const MAX_UPLOAD_BYTES = 2 * 1024 * 1024;
export async function readUploads(paths) {
  if (!Array.isArray(paths) || paths.length < 1 || paths.length > 4) throw new Error('Choose 1–4 explicitly authorized local files.');
  const files = []; let total = 0;
  for (const path of paths) {
    if (typeof path !== 'string' || !isAbsolute(path)) throw new Error('File paths must be absolute.');
    let handle;
    try {
      handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
      const stat = await handle.stat();
      if (!stat.isFile() || stat.size + total > MAX_UPLOAD_BYTES) throw new Error('Only regular files totaling at most 2 MiB are supported.');
      const buffer = Buffer.alloc(Math.min(stat.size + 1, MAX_UPLOAD_BYTES - total + 1));
      let size = 0;
      while (size < buffer.length) { const { bytesRead } = await handle.read(buffer, size, buffer.length - size, size); if (!bytesRead) break; size += bytesRead; }
      if (size > stat.size || size + total > MAX_UPLOAD_BYTES) throw new Error('File changed or upload limit exceeded; select it again.');
      const type = ({ '.pdf': 'application/pdf', '.txt': 'text/plain', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' })[extname(path).toLowerCase()] || 'application/octet-stream';
      files.push({ name: basename(path), type, data: buffer.subarray(0, size).toString('base64') }); total += size;
    } catch (error) { throw new Error(error.code ? 'A selected file could not be read. Choose an accessible regular file.' : error.message); }
    finally { await handle?.close(); }
  }
  return files;
}
