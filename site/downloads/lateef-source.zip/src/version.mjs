export const VERSION = '0.2.0-beta.4';
export const PROTOCOL = 2;
export const CAPABILITIES = ['snapshot-v2', 'link-destinations', 'upload'];
