# Security and trust boundaries

Lateef gives the MCP client real read/write access to explicitly controlled browser tabs. Pair only with clients you trust. Browser page text is untrusted data; an AI client must not follow instructions embedded in web pages as if they were user instructions.

The broker binds only to `127.0.0.1`, validates the Host header, rejects ordinary web origins, requires a private local admin token for MCP-side RPC, and authenticates extension WebSockets with a profile token. The token is never placed in a URL. Initial extension enrollment requires a single-use 96-bit pairing code with a two-minute expiry. The broker stores the extension token's SHA-256 hash, not the raw value.

The admin token is in the user's private state file, and the extension token is in Chrome extension-local storage. Other programs running as that same OS user may be able to access those secrets; this is not a sandbox against a compromised user account. File modes are best-effort platform permissions, not an encryption layer. Loopback traffic is local HTTP/WebSocket, not TLS.

DOM tools require session ownership and a currently selected window. A guessed tab ID grants no access. User-shared tabs cannot be closed by an agent. The extension has no content script, screenshot tool, desktop input, debugger permission, remote analytics, remote control server, provider API, or model invocation. It requests broad HTTP(S) host permissions so it can access agent-created tabs; those permissions are more extensive than a per-site allowlist. A per-site grant UI is a future hardening item.

Timeouts are ambiguous: an action may have run even if the result was lost. Mutations are never automatically retried. Reconnection does not authorize switching to another paired profile, window, or session.

Known limitation: the extension proves itself to the broker, but does not yet verify the broker in return. A local program that takes the broker's port while the broker is not running would receive the extension's pairing token on its next reconnect attempt. This needs code already running on your computer; a mutual challenge is planned.

This is an early prototype. Do not treat initial tests as an audit or a guarantee for sensitive workflows. Before public publication, the maintainer must enable private GitHub vulnerability reporting or provide a monitored security address. Do not publish sensitive exploit details in a public issue; do not include pairing codes, tokens, browser data, or authentication cookies in public reports.

Uploads: the AI client chooses the local file paths for `browser_upload`, so a manipulated client could try to attach sensitive files. Paths are resolved through symlinks and, by default, any path with a hidden component (such as `.ssh`, `.aws`, `.config`, `.env`), anything under `~/Library` and the Lateef state directory are refused. Setting `LATEEF_UPLOAD_ROOTS` (absolute directories separated by the platform path delimiter) narrows uploads to files inside those directories only. The `expectedOrigin` argument is supplied by the same agent, so it is a consistency check against navigation races, not user consent. Other files readable by your account remain attachable.
