# Changelog

## 0.2.0-beta.3

- First npm release. `lateef install <codex|claude|cursor>` registers the MCP server with a client; `lateef extension` copies the Chrome extension to a stable folder for Load unpacked.
- A copy run through npx registers itself as `npx -y lateef@<version> mcp`, so the client keeps working if the npx cache is cleared.
- Extension: a standing 30-second alarm reconnects after the service worker is suspended or the computer sleeps; previously it stayed disconnected until the popup was opened.
- Popup: clearer status, sharing controls only when a client is connected, stale-worker notice.

## 0.2.0-beta.2

- Breaking rename: the command is now only `lateef` (`node bin/lateef.mjs`); the state directory override is only `LATEEF_STATE_DIR`, and `LATEEF_TEST_CHROMIUM` selects the test Chromium.
- Upgrading: the state directory moved from `~/.config/quiet-chrome` to `~/.config/lateef`; move it, or pair again.
- Broker no longer exits on malformed extension frames (non-object or invalid JSON closes the socket) and survives stray unhandled rejections; commands carry an optional `deadline` so the extension skips work the client already saw time out; the extension reconnects with 1–30 s exponential backoff, avoids double connects, and stops retrying after the pairing is revoked; uploads resolve symlinks, refuse hidden paths, `~/Library` and the state directory by default, and honour an optional `LATEEF_UPLOAD_ROOTS` allowlist.

## 0.2.0-beta.1 — review build

- Lateef working brand and extension icon set; compatibility with previous CLI and state directory retained.
- Browser upload tool for 1–4 authorized regular files, 2 MiB total, with exact origin guard and hidden file-input references.
- DOM rows/cells, semantic depth, visible leaf text, link destinations and explicit truncation diagnostics.
- Setup/config/doctor commands; version/capability reporting and outdated-broker upload refusal.
- Sanitized release export, CI, product-page and store-submission drafts.

Not yet published. Live Gmail Sent/attachments, broader platform support, final publisher/contact, store approval and independent review remain release gates.
