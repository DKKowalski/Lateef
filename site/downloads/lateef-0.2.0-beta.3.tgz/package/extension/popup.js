const $ = id => document.getElementById(id);
const manifest = chrome.runtime.getManifest();
$('version').textContent = 'Lateef ' + (manifest.version_name || manifest.version);
let listed = '';
async function send(msg) { const reply = await chrome.runtime.sendMessage(msg); if (!reply?.ok) throw new Error(reply?.error || 'Extension did not answer'); return reply.result; }
async function refresh() {
  const [state, current] = await Promise.all([send({ type: 'status' }), chrome.windows.getCurrent()]);
  const connected = state.paired && state.status === 'Connected', here = state.windowId === current.id, sessions = state.sessions || [];
  // A background worker older than these popup files reports no (or another) version until the extension is reloaded.
  $('stale').hidden = state.version === manifest.version;
  $('state').textContent = state.paired ? state.status : 'Not paired';
  $('detail').textContent = !state.paired ? '' : !connected ? 'Waiting for the Lateef companion. It starts with your AI client.' : here ? 'Agents work in this window.' : 'Agents work in another window.';
  $('status').dataset.state = connected ? 'ok' : state.paired ? 'warn' : 'off';
  $('pair').hidden = state.paired; $('connected').hidden = !state.paired;
  $('window').hidden = here;
  $('sharing').hidden = !connected || !sessions.length; $('idle').hidden = !connected || sessions.length > 0;
  const key = JSON.stringify(sessions.map(session => [session.id, session.name]));
  if (key !== listed) { // Rebuild only on change so an open menu is not reset by the periodic refresh.
    const selected = $('sessions').value;
    $('sessions').replaceChildren(...sessions.map(session => { const option = document.createElement('option'); option.value = session.id; option.textContent = session.name; return option; }));
    if (sessions.some(session => session.id === selected)) $('sessions').value = selected;
    listed = key;
  }
}
function action(fn) { return async event => { event?.preventDefault(); $('error').textContent = ''; $('note').textContent = ''; try { await fn(); await refresh(); } catch (error) { $('error').textContent = error.message; } }; }
$('pair').onsubmit = action(async () => {
  const window = await chrome.windows.getCurrent();
  await send({ type: 'pair', port: Number($('port').value), code: $('code').value.trim(), name: $('name').value, windowId: window.id }); $('code').value = '';
});
$('window').onclick = action(async () => { const window = await chrome.windows.getCurrent(); await send({ type: 'window', windowId: window.id }); });
$('share').onclick = action(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }), name = $('sessions').selectedOptions[0]?.textContent;
  await send({ type: 'share', tabId: tab.id, sessionId: $('sessions').value }); $('note').textContent = `This tab is now shared with ${name}.`;
});
$('disconnect').onclick = action(() => send({ type: 'disconnect' }));
await refresh().catch(error => { $('state').textContent = 'Unavailable'; $('error').textContent = error.message; });
setInterval(() => refresh().catch(() => {}), 2000);
