// Runs in an isolated extension world, not the page's JavaScript namespace.
// No eval, screenshots, desktop input, focus(), or bring-to-front operations.
export function domCommand(method, params) {
  try {
  const state = globalThis.__quietChrome ??= { refs: new Map(), counter: 0 };
  const label = el => el.getAttribute('aria-label') ||
    (el.getAttribute('aria-labelledby') || '').split(/\s+/).map(id => document.getElementById(id)?.textContent || '').join(' ').trim() ||
    [...(el.labels || [])].map(label => label.innerText).join(' ') || el.innerText || el.getAttribute('placeholder') || el.getAttribute('title') || el.getAttribute('alt') || '';
  const visible = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const role = el => el.getAttribute('role') || ({ BUTTON: 'button', A: 'link', INPUT: el.type === 'checkbox' ? 'checkbox' : 'textbox', TEXTAREA: 'textbox', SELECT: 'combobox' }[el.tagName]) || el.tagName.toLowerCase();
  const compact = text => text.replace(/\s+/g, ' ').trim().slice(0, 200);
  const snapshot = () => {
    state.refs.clear(); state.counter = 0;
    const generation = Math.random().toString(36).slice(2, 10);
    const lines = [], nodes = [];
    const max = Math.min(Math.max(params.maxChars || 8000, 500), 20000);
    let length = 0, visited = 0;
    const reasons = new Set();
    const depthLimit = Math.min(params.depth || 12, 30);
    const addLine = line => { lines.push(line); length += line.length + 1; };
    function walk(parent, depth) {
      for (const el of parent.children || []) {
        if (++visited > 20000) { reasons.add('scanLimit'); return; }
        if (nodes.length >= 300) { reasons.add('nodeLimit'); return; }
        if (length >= max) { reasons.add('maxChars'); return; }
        if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE'].includes(el.tagName) || el.hidden || getComputedStyle(el).display === 'none') continue;
        const shown = visible(el);
        const interactive = shown && el.matches('button,a[href],input:not([type=hidden]),textarea,select,[role=button],[role=link],[role=row],[role=gridcell],[role=cell],[contenteditable=true]');
        const textElement = shown && el.matches('h1,h2,h3,h4,h5,h6,p,li,summary,output,td,th');
        const semantic = interactive || textElement;
        // Layout wrappers do not consume semantic depth. Traverse wrappers
        // without rectangles too (e.g. display:contents) to reach visible rows.
        if (semantic && depth > depthLimit) { reasons.add('depth'); continue; }
        if (interactive) {
          const ref = 'e' + generation + '_' + ++state.counter; state.refs.set(ref, el);
          const name = compact(label(el));
          const value = el.matches('input[type=password]') ? '[redacted]' : el.matches('input,textarea,select') ? String(el.value).slice(0, 120) : undefined;
          const link = el.closest('a[href]');
          const item = { ref, role: role(el), name, ...(link ? { href: link.href, target: link.getAttribute('target') || document.querySelector('base')?.target || '_self' } : {}), ...(value !== undefined ? { value } : {}), disabled: !!el.disabled };
          nodes.push(item);
          addLine(`${item.role} ${JSON.stringify(name)} [${ref}]${value !== undefined ? ' value=' + JSON.stringify(value) : ''}${el.disabled ? ' disabled' : ''}${link ? ' href=' + JSON.stringify(item.href) + ' target=' + JSON.stringify(item.target) : ''}`);
        } else if (textElement && el.childElementCount < 4) {
          const text = compact(el.innerText || el.textContent || '');
          if (text) addLine(`${el.tagName.toLowerCase()} ${text}`);
        } else if (shown && !el.children.length && !el.matches('input,textarea,select')) {
          const text = compact(el.innerText || el.textContent || '');
          if (text) addLine(`text ${text}`);
        }
        // Rows can contain buttons, links and cells; do not stop at their ref.
        if (!interactive || el.matches('[role=row],[role=gridcell],[role=cell]')) walk(el, depth + (semantic ? 1 : 0));
        if (el.shadowRoot) walk(el.shadowRoot, depth + (semantic ? 1 : 0));
      }
    }
    walk(document.body, 0);
    for (const input of document.querySelectorAll('input[type=file]')) {
      if (nodes.length >= 300 || length >= max) { reasons.add('nodeLimit'); break; }
      if ([...state.refs.values()].includes(input)) continue;
      const ref = 'e' + generation + '_' + ++state.counter; state.refs.set(ref, input);
      const item = { ref, role: 'file', name: compact(label(input)) || 'File input', multiple: input.multiple, accept: input.accept, hidden: !visible(input), disabled: input.disabled };
      nodes.push(item); addLine(`file ${JSON.stringify(item.name)} [${ref}]${item.hidden ? ' hidden' : ''}`);
    }
    if (length > max) reasons.add('maxChars');
    return { title: document.title, url: location.href, nodes, text: lines.join('\n').slice(0, max), truncated: reasons.size > 0, truncationReasons: [...reasons], limits: { maxChars: max, depth: depthLimit, maxNodes: 300, maxScannedElements: 20000 }, readyState: document.readyState };

  };
  if (method === 'snapshot' || method === 'find') {
    const result = snapshot();
    if (method === 'find') return { truncated: result.truncated, truncationReasons: result.truncationReasons, limits: result.limits, matches: result.nodes.filter(node => node.name.toLowerCase().includes(String(params.text).toLowerCase())).slice(0, Math.min(params.limit || 20, 50)) };
    return result;
  }
  const el = state.refs.get(params.ref);
  if (!el || !el.isConnected) throw new Error('STALE_REFERENCE: get a fresh snapshot');
  if ((!visible(el) && !(method === 'upload' && el.matches('input[type=file]'))) || el.disabled) throw new Error('ELEMENT_UNAVAILABLE: element is hidden or disabled');
  if (method === 'upload') {
    if (location.origin !== params.expectedOrigin) throw new Error('ORIGIN_MISMATCH: destination origin changed');
    if (!el.matches('input[type=file]')) throw new Error('NOT_FILE_INPUT: select a file input reference');
    if (!Array.isArray(params.files) || params.files.length < 1 || params.files.length > 4 || (!el.multiple && params.files.length > 1)) throw new Error('BAD_FILES: file count does not match this input');
    let total = 0;
    const transfer = new DataTransfer();
    for (const file of params.files) {
      if (typeof file.data !== 'string' || file.data.length > 2796208 || typeof file.name !== 'string') throw new Error('BAD_FILES: invalid file payload');
      const binary = atob(file.data); total += binary.length;
      if (total > 2097152) throw new Error('UPLOAD_LIMIT: files exceed 2 MiB');
      transfer.items.add(new File([Uint8Array.from(binary, c => c.charCodeAt(0))], file.name, { type: file.type || 'application/octet-stream' }));
    }
    el.files = transfer.files;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return { attached: params.files.map(f => ({ name: f.name })), bytes: total, origin: location.origin, eventType: 'DOM' };
  }
  if (method === 'click') {
    const anchor = el.closest('a[href]');
    const target = anchor?.getAttribute('target') || document.querySelector('base')?.target;
    if (anchor && target && !['_self', '_top', '_parent'].includes(target.toLowerCase())) {
      // Let SPA handlers cancel the click before emulating the native link.
      // Temporarily use _self so stopped propagation cannot activate a new tab.
      const originalTarget = anchor.getAttribute('target');
      anchor.setAttribute('target', '_self');
      let openUrl;
      const intercept = event => {
        if (event !== click) return;
        if (!event.defaultPrevented) openUrl = anchor.href;
        event.preventDefault();
      };
      const click = new MouseEvent('click', { bubbles: true, cancelable: true, composed: true, view: window });
      window.addEventListener('click', intercept);
      try { el.dispatchEvent(click); }
      finally {
        window.removeEventListener('click', intercept);
        if (originalTarget === null) anchor.removeAttribute('target');
        else anchor.setAttribute('target', originalTarget);
      }
      return openUrl ? { openUrl } : { clicked: params.ref };
    }
    const formTarget = el.form?.target;
    if (formTarget && !['_self', '_top', '_parent'].includes(formTarget.toLowerCase())) throw new Error('NEW_WINDOW_FORM: submitting into another window is unsupported');
    el.click(); return { clicked: params.ref };
  }
  if (method === 'fill') {
    if (el.matches('input[type=file],input[type=password]')) throw new Error('SENSITIVE_INPUT: file and password inputs are not supported in this MVP');
    if (el.matches('input[type=checkbox],input[type=radio]')) {
      if (typeof params.value !== 'boolean') throw new Error('Checkbox value must be boolean');
      if (el.checked !== params.value) el.click();
    } else if (el.matches('input,textarea,select')) {
      const proto = el.tagName === 'INPUT' ? HTMLInputElement.prototype : el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLSelectElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, String(params.value));
      el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable) { el.textContent = String(params.value); el.dispatchEvent(new Event('input', { bubbles: true })); }
    else throw new Error('Element cannot be filled');
    return { filled: params.ref };
  }
  throw new Error('Unknown DOM method');
  } catch (error) {
    const message = String(error.message || 'DOM operation failed').slice(0, 500);
    return { __quietError: { code: /^[A-Z_]+:/.test(message) ? message.split(':')[0] : 'DOM_ERROR', message } };
  }
}
