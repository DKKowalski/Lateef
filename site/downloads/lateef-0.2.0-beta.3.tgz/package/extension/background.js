import { domCommand } from './dom.js';

let socket, reconnecting = false, backoff = 1000, sessions = [], status = 'Disconnected';
let heartbeat;
let work = Promise.resolve();
function enqueue(fn) { work = work.catch(() => {}).then(fn); return work; }
const metadata = tab => ({ tabId: tab.id, windowId: tab.windowId, title: tab.title, url: tab.url });
const fail = (code, message) => { throw Object.assign(new Error(message), { code }); };
async function settings() { return (await chrome.storage.local.get('connection')).connection; }
async function ownership() { return (await chrome.storage.session.get('ownership')).ownership || {}; }
async function saveOwnership(value) { await chrome.storage.session.set({ ownership: value }); }
function urlAllowed(url) { try { return ['http:', 'https:'].includes(new URL(url).protocol); } catch { return false; } }
async function loaded(tabId) {
  const end = Date.now() + 10000;
  while (Date.now() < end) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === 'complete') return { ...metadata(tab), loading: false };
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  return { ...metadata(await chrome.tabs.get(tabId)), loading: true };
}

async function selectedWindow() {
  const config = await settings();
  if (!config) fail('NOT_PAIRED', 'Pair the extension first.');
  try { return await chrome.windows.get(config.windowId); }
  catch { fail('WINDOW_CLOSED', 'The selected window was closed. Choose a window in the extension popup.'); }
}
async function owned(sessionId, tabId) {
  const records = await ownership(), record = records[tabId];
  if (!record || record.sessionId !== sessionId) fail('TAB_NOT_SHARED', 'This tab does not belong to this session.');
  const window = await selectedWindow();
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) fail('TAB_CLOSED', 'The owned tab was closed.');
  if (tab.windowId !== window.id) fail('WINDOW_CHANGED', 'This tab is outside the selected window.');
  return tab;
}
async function dispatch(sessionId, method, params) {
  const records = await ownership();
  if (method === 'session.close') {
    for (const [id, record] of Object.entries(records)) if (record.sessionId === sessionId) {
      if (record.created) await chrome.tabs.remove(Number(id)).catch(() => {});
      delete records[id];
    }
    await saveOwnership(records); return { closed: true };
  }
  const window = await selectedWindow();
  if (method === 'tabs') {
    if (params.action === 'new') {
      if (params.url && !urlAllowed(params.url)) fail('URL_BLOCKED', 'Use an http(s) URL.');
      const tab = await chrome.tabs.create({ windowId: window.id, active: false, url: params.url || 'about:blank' });
      records[tab.id] = { sessionId, created: true }; await saveOwnership(records); return params.url ? loaded(tab.id) : metadata(tab);
    }
    if (params.action === 'close') {
      await owned(sessionId, params.tabId);
      if (!records[params.tabId]?.created) fail('NOT_OWNED', 'Shared user tabs are detached on session close, never closed by the agent.');
      await chrome.tabs.remove(params.tabId); delete records[params.tabId]; await saveOwnership(records); return { closed: params.tabId };
    }
    if (params.action !== 'list') fail('BAD_ACTION', 'Use list, new, or close.');
    const tabs = await chrome.tabs.query({ windowId: window.id });
    return { tabs: tabs.filter(tab => records[tab.id]?.sessionId === sessionId).map(metadata) };
  }
  const tab = await owned(sessionId, params.tabId);
  if (method === 'navigate') {
    if (!urlAllowed(params.url)) fail('URL_BLOCKED', 'Use an http(s) URL.');
    await chrome.tabs.update(tab.id, { url: params.url }); // Never changes active/focused.
    return loaded(tab.id);
  }
  if (!urlAllowed(tab.url)) fail('URL_BLOCKED', 'DOM tools operate on http(s) pages only.');
  if (method === 'upload' && new URL(tab.url).origin !== params.expectedOrigin) fail('ORIGIN_MISMATCH', 'The tab is no longer at the expected destination origin.');
  if (!['snapshot', 'find', 'fill', 'click', 'upload'].includes(method)) fail('UNKNOWN_METHOD', 'Unknown browser operation');
  const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'ISOLATED', func: domCommand, args: [method, params] });
  const result = results[0]?.result;
  if (result?.__quietError) fail(result.__quietError.code, result.__quietError.message);
  if (result === undefined) fail('DOM_NO_RESULT', 'The page did not return a DOM result. It may have navigated.');
  if (method === 'click' && result.openUrl) {
    if (!urlAllowed(result.openUrl)) fail('URL_BLOCKED', 'Only http(s) links can open a background tab.');
    const opened = await chrome.tabs.create({ windowId: window.id, active: false, url: result.openUrl });
    records[opened.id] = { sessionId, created: true }; await saveOwnership(records);
    return { opened: await loaded(opened.id) };
  }
  return result;
}

async function connect() {
  if (reconnecting || socket?.readyState === WebSocket.OPEN || socket?.readyState === WebSocket.CONNECTING) return;
  reconnecting = true;
  try {
    const config = await settings(); if (!config) { chrome.alarms.clear('reconnect'); return; }
    // A suspended or restarted worker gets no close event (sleep, idle shutdown), so a standing alarm is what brings the connection back.
    chrome.alarms.create('reconnect', { periodInMinutes: 0.5 });
    clearInterval(heartbeat);
    const connection = new WebSocket(`ws://127.0.0.1:${config.port}/extension`);
    socket = connection;
    connection.onopen = () => connection.send(JSON.stringify({ type: 'hello', pairId: config.pairId, token: config.token, windowId: config.windowId, version: chrome.runtime.getManifest().version, capabilities: ['snapshot-v2', 'link-destinations', 'upload'] }));
    connection.onmessage = async event => {
      let msg; try { msg = JSON.parse(event.data); } catch { return; }
      if (msg.type === 'ready') { status = 'Connected'; backoff = 1000; return; }
      if (msg.type === 'sessions') {
        sessions = msg.sessions;
        enqueue(async () => {
          const records = await ownership(), active = new Set(sessions.map(session => session.id));
          let changed = false;
          for (const [id, record] of Object.entries(records)) if (!active.has(record.sessionId)) {
            if (record.created) await chrome.tabs.remove(Number(id)).catch(() => {});
            delete records[id]; changed = true;
          }
          if (changed) await saveOwnership(records);
        }); return;
      }
      if (msg.type !== 'command') return;
      // Serialize ownership updates across clients to prevent lost records.
      enqueue(async () => {
        try {
          if (Number.isFinite(msg.deadline) && Date.now() > msg.deadline) fail('TIMEOUT', 'Command expired in the extension queue before it started; it was not run.');
          const result = await dispatch(msg.sessionId, msg.method, msg.params || {});
          if (connection.readyState === WebSocket.OPEN) connection.send(JSON.stringify({ type: 'result', id: msg.id, ok: true, result }));
        } catch (error) {
          if (connection.readyState === WebSocket.OPEN) connection.send(JSON.stringify({ type: 'result', id: msg.id, ok: false, error: { code: error.code || 'BROWSER_ERROR', message: error.message } }));
        }
      });
    };
    connection.onclose = event => {
      if (socket !== connection) return;
      status = 'Disconnected'; clearInterval(heartbeat);
      if (event.code === 1008 && /^Revoked/.test(event.reason)) { // Pairing revoked: stop retrying; the popup then shows not paired.
        socket = null; sessions = []; status = 'Not paired'; chrome.alarms.clear('reconnect'); chrome.storage.local.remove('connection'); return;
      }
      setTimeout(() => connect(), backoff); backoff = Math.min(backoff * 2, 30000);
    };
    connection.onerror = () => { if (socket === connection) status = 'Broker unavailable'; };
    heartbeat = setInterval(() => { if (connection.readyState === WebSocket.OPEN) connection.send(JSON.stringify({ type: 'ping' })); }, 20000);
  } finally { reconnecting = false; }
}

async function popupMessage(msg) {
  if (msg.type === 'status') { const config = await settings(); return { version: chrome.runtime.getManifest().version, status, windowId: config?.windowId, paired: !!config, sessions }; }
  if (msg.type === 'pair') {
    if (!Number.isInteger(msg.port) || msg.port < 1 || msg.port > 65535 || !Number.isInteger(msg.windowId)) fail('BAD_SETUP', 'Invalid port or window.');
    await chrome.windows.get(msg.windowId);
    const res = await fetch(`http://127.0.0.1:${msg.port}/pair`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code: msg.code, name: msg.name }) });
    if (!res.ok) fail('PAIR_FAILED', 'Pairing code was invalid or expired. Generate a new one.');
    const pair = await res.json();
    socket?.close();
    await chrome.storage.local.set({ connection: { port: msg.port, windowId: msg.windowId, ...pair } });
    socket = null; backoff = 1000; await connect(); return { paired: true };
  }
  if (msg.type === 'window') {
    await chrome.windows.get(msg.windowId); const config = await settings(); if (!config) fail('NOT_PAIRED', 'Pair first.');
    config.windowId = msg.windowId; await chrome.storage.local.set({ connection: config });
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: 'window', windowId: msg.windowId })); else await connect();
    return { windowId: msg.windowId };
  }
  if (msg.type === 'share') {
    if (!sessions.some(session => session.id === msg.sessionId)) fail('BAD_SESSION', 'Select an active client session.');
    const window = await selectedWindow(), tab = await chrome.tabs.get(msg.tabId);
    if (tab.windowId !== window.id || !urlAllowed(tab.url)) fail('TAB_NOT_IN_WINDOW', 'Share an http(s) tab from the selected window.');
    const records = await ownership();
    if (records[tab.id] && records[tab.id].sessionId !== msg.sessionId) fail('TAB_BUSY', 'Another session already controls this tab.');
    records[tab.id] = { sessionId: msg.sessionId, created: false }; await saveOwnership(records);
    socket.send(JSON.stringify({ type: 'bind', sessionId: msg.sessionId })); return { shared: tab.id };
  }
  if (msg.type === 'disconnect') {
    await chrome.storage.local.remove('connection'); socket?.close(); socket = null; clearInterval(heartbeat); sessions = []; status = 'Disconnected'; return { disconnected: true };
  }
  fail('BAD_REQUEST', 'Unknown popup request');
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Only our extension popup may pair, change window binding, or share user tabs.
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('popup.html')) return false;
  enqueue(() => popupMessage(msg)).then(result => sendResponse({ ok: true, result }), error => sendResponse({ ok: false, error: error.message })); return true;
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'reconnect') connect(); });
chrome.runtime.onStartup.addListener(connect);
chrome.tabs.onRemoved.addListener(id => enqueue(async () => { const records = await ownership(); if (records[id]) { delete records[id]; await saveOwnership(records); } }));
// Do not hold service-worker module evaluation open on Chrome API callbacks.
void connect();
